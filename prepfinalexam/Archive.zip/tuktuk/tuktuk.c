#include <unistd.h>

void	ft_putnbr(nb)
{
	if (nb == -2147483647)
		write(1, "-2147483647", 11);
	else if (nb == 0)
		write(1, "0", 1);
	else if (nb < 0)
	{
		write(1, "-", 1);
		nb = nb * -1;
		ft_putnbr(nb);
	}
	else if (nb > 9)
	{
		ft_putnbr(nb / 10);
		nb = nb % 10;
		ft_putnbr(nb);
	}
	else
	{
		nb = nb + '0';
		write(1, &nb, 1);
	}

}

void tuktuk(void)
{
	int nb = 0;
	while (nb >= 0 && nb <= 100)
	{
		if (nb == 0)
			write(1, "0", 1);
		else if (nb % 4  == 0 && nb % 7 == 0)
			write(1, "KebbabTucTuc", 12);
		else if (nb % 4 == 0)
			write(1, "kebbab", 6);
		else if (nb % 7 == 0)
			write(1, "tuctuc", 6);
		else
			ft_putnbr(nb);
		write(1, "\n", 1);
		nb++;
	}
}
int main(void)
{
	tuktuk();
}

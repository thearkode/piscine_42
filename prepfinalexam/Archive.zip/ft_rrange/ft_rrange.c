

int *new;

new = (int)malloc(sizeof(int) * len);

